﻿using Microsoft.EntityFrameworkCore;

namespace api_sanarate.Models
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Historia> Historias { get; set; }

        public static implicit operator ApplicationDbContext(System.Data.Entity.DbContext v)
        {
            throw new NotImplementedException();
        }
    }
}
