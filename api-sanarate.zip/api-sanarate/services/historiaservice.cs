﻿using api_sanarate.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Threading.Tasks;
using DbContext = System.Data.Entity.DbContext;

namespace api_sanarate.Services
{
    public class HistoriaService 
    {
        // El contexto de base de datos para interactuar con la tabla 'Historia'
        private readonly ApplicationDbContext _dbContext;

        // Constructor que recibe el contexto de la base de datos a través de inyección de dependencias
        public HistoriaService(ApplicationDbContext context, DbContext dbContext)
        {
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(DbContext));
        }

        // Método para obtener todas las historias desde la base de datos
        public async Task<List<Historia>> GetAllHistoriasAsync()
        {
            try
            {
                // Realiza la consulta a la tabla 'Historia' y devuelve la lista
                return await _dbContext.Historias.ToListAsync();
            }
            catch (Exception ex)
            {
                // Captura cualquier excepción que ocurra y lanza un nuevo error con un mensaje personalizado
                throw new Exception("Error al obtener las historias", ex);
            }
        }

        // Método para obtener una historia específica por ID
        public async Task<Historia> GetHistoriaByIdAsync(int id)
        {
            try
            {
                // Busca la historia por su clave primaria (ID)
                var historia = await _dbContext.Historias.FindAsync(id);

                // Si la historia no se encuentra, lanza una excepción personalizada
                if (historia == null)
                {
                    throw new Exception($"Historia con id {id} no encontrada");
                }

                // Devuelve la historia encontrada
                return historia;
            }
            catch (Exception ex)
            {
                // Captura cualquier excepción que ocurra y lanza un nuevo error con un mensaje personalizado
                throw new Exception("Error al obtener la historia", ex);
            }
        }

        // Método para agregar una nueva historia a la base de datos
        public async Task AddHistoriaAsync(Historia objeto)
        {
            try
            {
                // Agrega la nueva historia al contexto y guarda los cambios
                await _dbContext.Historias.AddAsync(objeto);
                await _dbContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Captura cualquier excepción que ocurra y lanza un nuevo error con un mensaje personalizado
                throw new Exception("Error al agregar la historia", ex);
            }
        }

        // Método para actualizar una historia existente en la base de datos
        public async Task<bool> UpdateHistoriaAsync(int id, Historia objeto)
        {
            try
            {
                // Busca la historia existente por su ID
                var historiaExistente = await _dbContext.Historias.FindAsync(id);

                // Si la historia no existe, devuelve false indicando que no se pudo actualizar
                if (historiaExistente == null)
                {
                    return false;
                }

                // Actualiza las propiedades de la historia existente con los datos del nuevo objeto
                historiaExistente.evento = objeto.evento;
                historiaExistente.descripcion = objeto.descripcion;
                historiaExistente.fecha = objeto.fecha;
                historiaExistente.imagen = objeto.imagen;

                // Guarda los cambios en la base de datos
                await _dbContext.SaveChangesAsync();
                return true; // Devuelve true indicando que la actualización fue exitosa
            }
            catch (Exception ex)
            {
                // Captura cualquier excepción que ocurra y lanza un nuevo error con un mensaje personalizado
                throw new Exception("Error al actualizar la historia", ex);
            }
        }

        // Método para eliminar una historia por su ID
        public async Task<bool> DeleteHistoriaAsync(int id)
        {
            try
            {
                // Busca la historia por su ID
                var historia = await _dbContext.Historias.FindAsync(id);

                // Si la historia no existe, devuelve false indicando que no se pudo eliminar
                if (historia == null)
                {
                    return false;
                }

                // Elimina la historia del contexto
                _dbContext.Historias.Remove(historia);

                // Guarda los cambios en la base de datos
                await _dbContext.SaveChangesAsync();
                return true; // Devuelve true indicando que la eliminación fue exitosa
            }
            catch (Exception ex)
            {
                // Captura cualquier excepción que ocurra y lanza un nuevo error con un mensaje personalizado
                throw new Exception("Error al eliminar la historia", ex);
            }
        }
    }
}