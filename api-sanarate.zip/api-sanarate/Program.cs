using Microsoft.EntityFrameworkCore;
using api_sanarate.Services;
using api_sanarate.Models;

var builder = WebApplication.CreateBuilder(args);

// Configuraci�n de la conexi�n a MySQL (usando MySQL Workbench para gestionar la base de datos)
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseMySql(builder.Configuration.GetConnectionString("DefaultConnection"),
    options => options.EnableRetryOnFailure()));

// Agregar el servicio de Historia
builder.Services.AddScoped<HistoriaService, HistoriaService>();

// Agregar controladores
builder.Services.AddControllers();

// Swagger/OpenAPI
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configuraci�n del pipeline HTTP
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();